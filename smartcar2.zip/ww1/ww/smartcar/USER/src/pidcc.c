#include "pidcc.h"
#include "common.h"
#include "headfile.h"
#include "motor.h"
#include "steer.h"

#define LOC_INTEGRAL_START_ERR 200  /*���ַ���ʱ��Ӧ����Χ*/
#define LOC_INTEGRAL_MAX_VAL 800   /*���ַ�Χ�޶�����ֹ���ֱ���*/
#define SPE_DEAD_ZONE   5.0f       /*�ٶȻ�����*/

// steer pid

#define con 20             //adcת������           ���ɵ���
#define NORMAL_SPEED 2200  //ֱ���ٶ�							 ���ɵ���
#define STOP_SPEED 1500    //��⵽ֹͣ��־ʱ���ٶȣ��ɵ���
#define CIRCLE_SPEED 2000  //�����ٶ�              ���ɵ���

#define angle_left_pwm    1980     //�󻷵� �뻷�����Ƕ�Ӧpwm                                                ���ɵ���
#define angle_right_pwm   1680     //�һ��� �뻷�����Ƕ�Ӧpwm 																							 ���ɵ���
#define incircle_delay_ms   200     //���ñ���������·�̵Ļ�����ֵΪ��⵽Ԥ������־�󣬴�̶���֮ǰ��ʱ��ʱ��   (�ɵ�)
#define outcircle_delay_ms  20     //���ñ���������·�̵Ļ�����ֵΪ��⵽Ԥ������־�󣬴�̶���֮����ʱ��ʱ��   (�ɵ�)

#define incircle_threshold1  500    //�뻷����adc������adc�ж���ֵ                                              ���ɵ���
#define incircle_threshold2  3900    //�뻷�м�adc�ж���ֵ                                                       ���ɵ���
//#define incircle_threshold3  10    //�뻷adc�ж���ֵ     ��Ҫʱ���ټ�
#define outcircle_threshold1  10    //��������adc������adc�ж���ֵ                                              ���ɵ���
#define outcircle_threshold2  10    //�����м�adc�ж���ֵ                                                       ���ɵ���
//#define outcircle_threshold3  10    //����adc�ж���ֵ     ��Ҫʱ���ټ�


int speedflag=1;           //ֱ����ֹͣ�������жϱ�־
PID pid_steer;
iPID ipid_speed_left;
iPID ipid_speed_right;


float setpoint_left=2200.0; // setpoint_left -> left ��߱�׼�ٶ�    setpoint_right -> right  �ұ߱�׼�ٶ�
float setpoint_right=2200.0;
int adc_left_edge,  adc_left_mid,  adc_mid,  adc_right_mid,  adc_right_edge;  //���������С����ҡ�����adc�Ķ�ȡ��ֵ��Ӧ����Ϊȫ�ֱ�����
int status=1;                      //���뻷��־λ(������־λ)����⵽Ԥ�뻷״̬��ֵΪ0������Ϊ1,��һ�������ֵ��Ϊ1


void PID_param_init()
{
    /* ????????? */
    pid_steer.target_val =0;               
    pid_steer.output_val = 1880;
    pid_steer.err = 0.0;
    pid_steer.err_last = 0.0;
    pid_steer.integral = 0.0;

    pid_steer.Kp = 0.05;
    pid_steer.Ki = 0;
    pid_steer.Kd = 0;
    pid_steer.input_val=0;
	  pid_steer.Kp_output_val=0;
	  pid_steer.Ki_output_val=0;
	  pid_steer.Kd_output_val=0;
    /* ????????? */
    ipid_speed_left.target_val=10.0;              
    ipid_speed_left.output_val=0.0;
    ipid_speed_left.err=0.0;
    ipid_speed_left.err_last=0.0;
	
    ipid_speed_left.Kp_output_val=0;
		ipid_speed_left.Ki_output_val=0;
		ipid_speed_left.Kd_output_val=0;
		
    ipid_speed_left.Kp = 80.0;
    ipid_speed_left.Ki = 2.0;
    ipid_speed_left.Kd = 100.0;
		ipid_speed_left.input_val=0;
		ipid_speed_left.integral=0.0;
		
		ipid_speed_right.target_val=10.0;              
    ipid_speed_right.output_val=0.0;
    ipid_speed_right.err=0.0;
    ipid_speed_right.err_last=0.0;

		ipid_speed_right.Kp_output_val=0;
		ipid_speed_right.Ki_output_val=0;
		ipid_speed_right.Kd_output_val=0;
		
		ipid_speed_right.integral=0.0;

    ipid_speed_right.Kp = 80.0;
    ipid_speed_right.Ki = 2.0;
    ipid_speed_right.Kd = 100.0;
		ipid_speed_right.input_val=0;
		
		
		ipid_speed_left.omin=4000;
		ipid_speed_left.omax=4000;
		ipid_speed_right.omin=4000;
		ipid_speed_right.omax=4000;
}

//**************************//
//*****�����뻷adc���******//
//**************************//
int judge_circle_in(float adc_left_edge,float adc_right_edge,float adc_mid){
        if((adc_left_edge - adc_right_edge > incircle_threshold1 ||adc_right_edge - adc_left_edge > incircle_threshold1 )&& adc_mid > incircle_threshold2)return 1;
	      else return 0;
	      
}

//int judge_circle_in(float adc_mid){
//        //if(adc_left_edge - adc_right_edge > incircle_threshold1 && adc_mid > incircle_threshold2)return 1;
//	      //else return 0;
//	      if( adc_mid > incircle_threshold2)return 1;
//	      else return 0;
//}

//**************************//
//*****��������adc���******//
//**************************//
int judge_circle_out(float adc_left_edge,float adc_right_edge,float adc_mid){
        if(adc_left_edge - adc_right_edge > outcircle_threshold1 && adc_mid > outcircle_threshold2)return 1;
	      else return 0;
}
//***********************//
//*****������⺯��******//
//***********************//
//����������������       ͣ����־λ��ʱ����ⲿ�ж�
void judge_circle(){
    if(status  &&  judge_circle_in(adc_left_mid,adc_right_mid,adc_mid) ){
		     status=0;
			    delay_ms(incircle_delay_ms); 
			   PWMSetSteer(angle_right_pwm);
			   delay_ms(incircle_delay_ms);     //ֱ���ٶȿ죬���������ʱ������ҪСһ��
			   
			   speedflag=2;
			   
		}
		
//		if(status == 0 && judge_circle_out(adc_left_mid,adc_right_mid,adc_mid) ){
//		     speedflag=1;
//			   PWMSetSteer(angle_left_pwm);
//			   delay_ms(outcircle_delay_ms);  
//			   status=1;	
//		} 
//		else if(judge_right(adc_right_edge,adc_right_mid,adc_mid)=1){
//		     circleflag=1;
//			   PWMSetSteer(angle_right_pwm);
//			   speedflag=2;
//		}

}

//***************************//
//*****adc�ɼ��Ӷ��pid******//
//***************************//
void pid_steers(){
	adc_left_mid=Filter(ADC_P01,ADC_12BIT);
	adc_right_mid=Filter(ADC_P05,ADC_12BIT);
	adc_mid=Filter(ADC_P00,ADC_12BIT);
	//adc_left_edge=Filter(ADC_P00,ADC_12BIT); //��ͨ��
	//adc_right_edge=Filter(ADC_P00,ADC_12BIT);//��ͨ��
	//adc_mid=Filter(ADC_P00,ADC_12BIT);       //��ͨ��
	ele_direction_control(&pid_steer,&ipid_speed_left,&ipid_speed_right,adc_left_mid,adc_right_mid);
}

void ele_direction_control(PID* topid_steer,iPID* toipid_speed_left,iPID* toipid_speed_right,float adc_left_mid,float adc_right_mid)
{
        //int i = H-21;
        //ADresult0 = 0;
        
        //for(;i>H-41;i--)
        //{
        // ADresult0 += Pick_table[i];     
        //}
        
        //ADresult1 = NUMPIX*10;
        // topid_steer->err = (int)(ADresult0-ADresult1)/20;
        topid_steer->err =(int)(adc_left_mid-adc_right_mid)/con;//�����ֵ�������
	 
        //uart_printf(UART_0," topid_steer->err =  %d\n", topid_steer->err);

                       
        if(-30>topid_steer->err)//��ƫ����
        {speedflag =2;
            topid_steer->Kp=5;
            topid_steer->Kp_output_val=topid_steer->Kp* topid_steer->err;
            if(speedflag == 1)
            {
                setpoint_left = NORMAL_SPEED+2.5*topid_steer->err;
                setpoint_right = NORMAL_SPEED;
            }
            else if(speedflag == 2)
            {
                setpoint_left = CIRCLE_SPEED+4*topid_steer->err;
                setpoint_right = CIRCLE_SPEED;
            }
            else if(speedflag == 5)
            {
              setpoint_right = STOP_SPEED;
                setpoint_left = STOP_SPEED+1*topid_steer->err;
            }
        }
				
        else if(-20>=topid_steer->err && topid_steer->err>=-30)//��ƫ�ϴ�
        {speedflag =2;
            topid_steer->Kp=4;
            topid_steer->Kp_output_val=topid_steer->Kp*topid_steer->err;
            if(speedflag == 1)
            {
              setpoint_left = NORMAL_SPEED+4*topid_steer->err;
              setpoint_right = NORMAL_SPEED;
            }
            else if(speedflag == 2)
            {
                setpoint_left = CIRCLE_SPEED+10*topid_steer->err;
                setpoint_right = CIRCLE_SPEED;
            }
            else if(speedflag == 5)
            {
              setpoint_right = STOP_SPEED;
                setpoint_left = STOP_SPEED+1*topid_steer->err;
            }
        }
        else if(-13>topid_steer->err && topid_steer->err>-20)//��ƫ��С
        {speedflag =2;
            topid_steer->Kp=4;
            topid_steer->Kp_output_val=topid_steer->Kp*topid_steer->err;
            if(speedflag == 1)
            {
              setpoint_left = NORMAL_SPEED+1*topid_steer->err;
              setpoint_right = NORMAL_SPEED;
            }
            else if(speedflag == 2)
            {
                setpoint_left = CIRCLE_SPEED+5*topid_steer->err;
                setpoint_right = CIRCLE_SPEED;
            }
            else if(speedflag == 5)
            {
              setpoint_right = STOP_SPEED;
                setpoint_left = STOP_SPEED+1*topid_steer->err;
            }
        } 
        else if(-13<=topid_steer->err && topid_steer->err<0)//��������ƫ
        {speedflag =1;
            topid_steer->Kp=2;
            topid_steer->Kp_output_val=topid_steer->Kp*topid_steer->err;
           if(speedflag == 1)
            {
              setpoint_left = setpoint_right = NORMAL_SPEED;
            }
              else if(speedflag == 2)
            {
              setpoint_left = setpoint_right = CIRCLE_SPEED;
            }
           
        }
        else if(0<=topid_steer->err && topid_steer->err<=13)//��������ƫ
        {speedflag =1;
            topid_steer->Kp=2;
            topid_steer->Kp_output_val=topid_steer->Kp*topid_steer->err;
           if(speedflag == 1)
            {
              setpoint_left = setpoint_right = NORMAL_SPEED;
            }
           else if(speedflag == 2)
            {
              setpoint_left = setpoint_right = CIRCLE_SPEED;
            }
           
        }
        else if(13<topid_steer->err && topid_steer->err<20)//��ƫ��С
        {speedflag =2;
            topid_steer->Kp=4;
            topid_steer->Kp_output_val=topid_steer->Kp*topid_steer->err;
           if(speedflag == 1)
            {
              setpoint_right = NORMAL_SPEED-1*topid_steer->err;
                setpoint_left = NORMAL_SPEED;
            }
           else if(speedflag == 2)
            {
              setpoint_right = CIRCLE_SPEED-5*topid_steer->err;
                setpoint_left = CIRCLE_SPEED;
            }
           else if(speedflag == 5)
            {
              setpoint_right = STOP_SPEED-1*topid_steer->err;
                setpoint_left = STOP_SPEED;
            }
        }
        else if(20<=topid_steer->err && topid_steer->err<30)//��ƫ�ϴ�
        {speedflag =2;
            topid_steer->Kp=4;
            topid_steer->Kp_output_val=topid_steer->Kp*topid_steer->err;
            if(speedflag == 1)
            {
              setpoint_right = NORMAL_SPEED-1*topid_steer->err;
              setpoint_left = NORMAL_SPEED;
            }
            else if(speedflag == 2)
            {
              setpoint_right = CIRCLE_SPEED-4*topid_steer->err;
                setpoint_left = CIRCLE_SPEED;
            }
            else if(speedflag == 5)
            {
              setpoint_right = STOP_SPEED-1*topid_steer->err;
                setpoint_left = STOP_SPEED;
            }
        }else if(30<=topid_steer->err)//��ƫ����
        {speedflag =2;
            topid_steer->Kp=5;
            topid_steer->Kp_output_val=topid_steer->Kp*topid_steer->err;
            if(speedflag == 1)
            {
              setpoint_right = NORMAL_SPEED-2.5*topid_steer->err;
              setpoint_left = NORMAL_SPEED;
            }
            else if(speedflag == 2)
            {
              setpoint_right = CIRCLE_SPEED-4*topid_steer->err;
              setpoint_left = CIRCLE_SPEED;
            }else if(speedflag == 5)
            {
                setpoint_right = STOP_SPEED-1*topid_steer->err;
                setpoint_left = STOP_SPEED;
            }
        }
        
        
        if(topid_steer->Kp_output_val<-200)topid_steer->Kp_output_val=-200;//��Kp���õ�����ֵ�����޷�
        if(topid_steer->Kp_output_val>200)topid_steer->Kp_output_val=200;  //��Kp���õ�����ֵ�����޷�
        
        //uart_printf(UART_0,"output = %f\n",dir_P_value);
        
        topid_steer->Kd=10;                                              //��ֵKd
        topid_steer->Kd_output_val=topid_steer->Kd*(topid_steer->err-topid_steer->err_last); //�������Kd������ֵ
          
        topid_steer->output_val=(int)(topid_steer->Kp_output_val+topid_steer->Kd_output_val);   //Kd����ֵ+Kp����ֵ  �������յ�����ֵ
        topid_steer->err_last=topid_steer->err;                               //���˴μ����ƫ��浽last_err��Ա�΢�ֵ�����

				
				
				toipid_speed_left->target_val=(int)setpoint_left;																															//�����ٶȻ�
				toipid_speed_right->target_val=	(int)setpoint_right;	
				
        PWMSetSteer(1880+topid_steer->output_val);                        //������
}

//�ٶȻ�   ����Ŀ���ٶ� 
int speedleft_pid_realize(iPID *toipid_left_speed ,int actual_val_left ){
  int error_left;
	
	error_left=toipid_left_speed->target_val-actual_val_left;
	toipid_left_speed->err=error_left;
	
	if(error_left < 0)
    {
      toipid_left_speed->Kp = 300;
    }
    else
    {
      toipid_left_speed->Kp = 100;
    }
    
		
		   //��������
		    if( (toipid_left_speed->err>-SPE_DEAD_ZONE) && (toipid_left_speed->err<SPE_DEAD_ZONE ) )
    {
        toipid_left_speed->err = 0;
        toipid_left_speed->integral = 0;
        toipid_left_speed->err_last = 0;
    }


				//���ַ���
		if(toipid_left_speed->err> -LOC_INTEGRAL_START_ERR && toipid_left_speed->err < LOC_INTEGRAL_START_ERR){
	      toipid_left_speed->integral += toipid_left_speed->err;  
        /*���ַ�Χ�޶�����ֹ���ֱ���*/
        if(toipid_left_speed->integral > LOC_INTEGRAL_MAX_VAL)
        {
           toipid_left_speed->integral = LOC_INTEGRAL_MAX_VAL;
        }
        else if(toipid_left_speed->integral < -LOC_INTEGRAL_MAX_VAL)
        {
            toipid_left_speed->integral= -LOC_INTEGRAL_MAX_VAL;
        }
			}
				
			//�ٶ��޷�
		 if(toipid_left_speed->integral>toipid_left_speed->omax)
      toipid_left_speed->integral=toipid_left_speed->omax;
    else if(toipid_left_speed->integral<toipid_left_speed->omin)
      toipid_left_speed->integral=toipid_left_speed->omin;
		
		//���
		toipid_left_speed->output_val=toipid_left_speed->Kp*toipid_left_speed->err+toipid_left_speed->Ki*toipid_left_speed->integral+toipid_left_speed->Kd*(toipid_left_speed->err-toipid_left_speed->err_last);
		toipid_left_speed->err_last= toipid_left_speed->err;
		return (int)toipid_left_speed->output_val;

}
int speedright_pid_realize(iPID *toipid_right_speed,int actual_val_right){
	int error_right;
	error_right=toipid_right_speed->target_val-actual_val_right;
	toipid_right_speed->err=error_right;
	
    if(error_right< 0)
    {
     toipid_right_speed->Kp = 300;
    }
    else
    {
     toipid_right_speed->Kp= 100;
    }
		
		   //��������
		    if( (toipid_right_speed->err>-SPE_DEAD_ZONE) && (toipid_right_speed->err<SPE_DEAD_ZONE ) )
    {
        toipid_right_speed->err = 0;
        toipid_right_speed->integral = 0;
        toipid_right_speed->err_last = 0;
    }


				//���ַ���
			if(toipid_right_speed->err> -LOC_INTEGRAL_START_ERR && toipid_right_speed->err < LOC_INTEGRAL_START_ERR){
	      toipid_right_speed->integral += toipid_right_speed->err;  
        /*���ַ�Χ�޶�����ֹ���ֱ���*/
        if(toipid_right_speed->integral > LOC_INTEGRAL_MAX_VAL)
        {
           toipid_right_speed->integral = LOC_INTEGRAL_MAX_VAL;
        }
        else if(toipid_right_speed->integral < -LOC_INTEGRAL_MAX_VAL)
        {
            toipid_right_speed->integral= -LOC_INTEGRAL_MAX_VAL;
        }
		}
				
			//�ٶ��޷�
    if(toipid_right_speed->integral>toipid_right_speed->omax)
      toipid_right_speed->integral=toipid_right_speed->omax;
    else if(toipid_right_speed->integral<toipid_right_speed->omin)
      toipid_right_speed->integral=toipid_right_speed->omin;
		
		//���
		toipid_right_speed->output_val=toipid_right_speed->Kp*toipid_right_speed->err+toipid_right_speed->Ki*toipid_right_speed->integral+toipid_right_speed->Kd*(toipid_right_speed->err-toipid_right_speed->err_last);
    toipid_right_speed->err_last= toipid_right_speed->err;
		return (int)toipid_right_speed->output_val;
}
void  speed_pid(){
    PWMSetMotor2(speedleft_pid_realize(&ipid_speed_left,ipid_speed_left.input_val),speedright_pid_realize(&ipid_speed_right,ipid_speed_right.input_val));
}